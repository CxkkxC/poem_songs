//app.js
App({
  onLaunch: function () {
  },
  globalData: {
    openid: null,
    nickname:'',
    // url:'http://127.0.0.1:5000/',
    url: 'https://www.cxkboke.top/',
  }
})