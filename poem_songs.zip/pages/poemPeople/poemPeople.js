﻿// pages/poemPeople/poemPeople.js
//获取应用实例
const app = getApp()
Page({
  data: {
    isHide: false,
    userInfo: "",
    mode: ["修改个人资料", "个人分享语音", "个人原创诗集", "关于诗音情"],
    ico_url: ["/images/1.png", '/images/2.png', '/images/3.png', '/images/4.png'],
    hiddenmodalput: true,
    hiddenmodalput2: true,
    signlen: 0,
    nickname: "",
    sign: "",
    newnickname: "",
    newsign: "",
    question: "",
    allquestion: "",
    use_audio: [],
    use_poem: []
  },
  getUsrPoem: function () {
    wx.request({
      url: app.globalData.url + "getUsePoem",
      method: 'post',
      header: {
        'content-type': 'application/json'
      },
      data: {
        openid: app.globalData.openid,
      },
      success: res => {
        //console.log(res.data)
        this.setData({
          use_audio: res.data.use_audio,
          use_poem: res.data.use_poem
        })
      }
    })
  },
  getnickname: function (e) {
    //console.log(e.detail.value)
    this.setData({
      newnickname: e.detail.value
    })
  },
  getsign: function (e) {
    var str = e.detail.value
    this.setData({
      signlen: str.length,
      newsign: str
    })
  },
  //取消按钮
  cancel: function () {
    this.setData({
      hiddenmodalput: true,
      newnickname: this.data.nickname,
      newsign: this.data.sign
    });
  },
  //确认
  confirm: function () {
    if (this.data.newnickname.length != 0) {
      if (this.data.newnickname != this.data.nickname || this.data.newsign != this.data.sign) {
        wx.request({
          url: app.globalData.url + "alter_info",
          method: 'post',
          header: {
            'content-type': 'application/json'
          },
          data: {
            openid: app.globalData.openid,
            nickname: this.data.newnickname,
            sign: this.data.newsign,
          },
          success: res => {
            //console.log(res.data)
            if (res.data.openid == 'None') {
              this.setData({
                hiddenmodalput: true,
              })
              app.globalData.openid = null
              this.onLoad()
            } else {
              this.setData({
                userInfo: res.data.userInfo,
                hiddenmodalput: true,
                nickname: res.data.userInfo.nickname,
                sign: res.data.userInfo.sign,
                newnickname: res.data.userInfo.nickname,
                newsign: res.data.userInfo.sign,
              })
            }

          },
        })
      } else {
        this.setData({
          hiddenmodalput: true,
        })
        //console.log("资料未修改")
      }
    } else {
      wx.showToast({
        title: '输入为空',
        duration: 1000
      })
    }
  },
  getquestion: function (e) {
    //console.log(e.detail.value)
    this.setData({
      question: e.detail.value,
    });
  },
  getallquestion: function (e) {
    //console.log(e.detail.value)
    this.setData({
      allquestion: e.detail.value,
    });
  },
  //取消按钮
  cancel2: function () {
    this.setData({
      hiddenmodalput2: true,
      question: "",
      allquestion: ""
    });
  },
  //确认
  confirm2: function () {
    if (this.data.question.length != 0 && this.data.allquestion.length != 0) {
      wx.request({
        url: app.globalData.url + "get_question",
        method: 'post',
        header: {
          'content-type': 'application/json'
        },
        data: {
          openid: app.globalData.openid,
          question: this.data.question,
          allquestion: this.data.allquestion,
        },
        success: res => {
          //console.log(res.data)
          this.setData({
            hiddenmodalput2: true,
          })
          wx.showToast({
            title: res.data.msg,
            icon: "success",
            duration: 1500
          })
        },
        fail: res => {
          wx.showToast({
            title: res.data.msg,
            icon: "none",
            duration: 1500
          })
        }
      })
    } else {
      wx.showToast({
        title: '输入为空',
        duration: 1000
      })
    }

  },
  //点击按钮弹出指定的hiddenmodalput弹出框
  onclick0: function () {
    this.setData({
      hiddenmodalput: !this.data.hiddenmodalput
    })
  },
  onclick1: function (e) {
    // var str = parseInt(e.currentTarget.id)
    wx.setStorageSync('use_audio', this.data.use_audio)
    wx.navigateTo({
      url: '/pages/audioList/audioLsit',
    })
  },
  onclick2: function (e) {
    // var str = parseInt(e.currentTarget.id)
    wx.setStorageSync('use_poem', this.data.use_poem)
    wx.navigateTo({
      url: '/pages/poemList/poemLsit',
    })
  },
  onclick3: function (e) {
    wx.navigateTo({
      url: "/pages/about/about"
    });
  },
  onLoad: function () {
    var that = this;
    // 查看是否授权
    wx.getSetting({
      success: function (res) {
        if (res.authSetting['scope.userInfo']) {
          wx.getUserInfo({
            success: function (res_user) {
              // 用户已经授权过,不需要显示授权页面,所以不需要改变 isHide 的值
              // 根据自己的需求有其他操作再补充
              // 我这里实现的是在用户授权成功后，调用微信的 wx.login 接口，从而获取code
              wx.login({
                success: res => {
                  // 获取到用户的 code 之后：res.code
                  //console.log("用户的code:" + res.code);
                  // 可以传给后台，再经过解析获取用户的 openid
                  // 或者可以直接使用微信的提供的接口直接获取 openid ，方法如下：
                  wx.request({
                    // 自行补上自己的 APPID 和 SECRET
                    url: app.globalData.url + "get_id",
                    method: 'post',
                    header: {
                      'content-type': 'application/json'
                    },
                    data: {
                      code: res.code,
                      headurl: res_user.userInfo.avatarUrl, //这些是用户的基本信息
                      nickname: res_user.userInfo.nickName, //获取昵称
                      gender: res_user.userInfo.gender //性别 0：未知、1：男、2：女
                    },
                    success: res => {
                      //console.log(res.data)
                      // 获取到用户的 openid
                      //console.log("用户的openid:" + res.data.openid);
                      app.globalData.openid = res.data.openid
                      app.globalData.nickname = res.data.userInfo.nickname
                      that.setData({
                        userInfo: res.data.userInfo,
                        nickname: res.data.userInfo.nickname,
                        sign: res.data.userInfo.sign,
                        newnickname: res.data.userInfo.nickname,
                        newsign: res.data.userInfo.sign,
                      });
                      wx.showToast({
                        title: '登录成功',
                        icon: "none",
                        duration: 1500
                      })
                      that.getUsrPoem()
                    }
                  });
                }
              });
            }
          });
        } else {
          // 用户没有授权
          // 改变 isHide 的值，显示授权页面
          that.setData({
            isHide: true
          });
        }
      }
    });
  },
  bindGetUserInfo: function (e) {
    if (e.detail.userInfo) {
      //用户按了允许授权按钮
      var that = this;
      // 获取到用户的信息了，打印到控制台上看下
      //console.log("用户的信息如下：");
      //console.log(e.detail.userInfo);
      //授权成功后,通过改变 isHide 的值，让实现页面显示出来，把授权页面隐藏起来
      that.setData({
        isHide: false,
      });
      this.onLoad();
    } else {
      //用户按了拒绝按钮
      wx.showModal({
        title: '警告',
        content: '您点击了拒绝授权，无法分享语音，请授权之后再进入!!',
        showCancel: false,
        confirmText: '返回授权',
        success: function (res) {
          // 用户没有授权成功，不需要改变 isHide 的值
          if (res.confirm) {
            //console.log('用户点击了“返回授权”');
          }
        }
      });
    }
  },
  del_allinfo: function () {
    //console.log(app.globalData.openid)
    wx.showModal({
      title: '警告',
      content: '您确定将该账户注销？',
      success(res) {
        if (res.confirm) {
          //console.log('用户点击确定')
          wx.showModal({
            title: '警告',
            content: '您确定你不是误点？',
            success(res) {
              if (res.confirm) {
                wx.request({
                  url: app.globalData.url + "del_all",
                  method: 'post',
                  header: {
                    'content-type': 'application/json'
                  },
                  data: {
                    openid: app.globalData.openid
                  },
                  success: res => {
                    //console.log(res.data.msg)
                    wx.showModal({
                      title: '提示',
                      content: res.data.msg,
                      success(res) {
                        if (res.confirm) {
                          //console.log('用户点击确定')
                          wx.setStorageSync('use_audio', [])
                          wx.setStorageSync('use_poem', [])
                        } else if (res.cancel) {
                          //console.log('用户点击取消')
                          wx.setStorageSync('use_poem', [])
                          wx.setStorageSync('use_audio', [])
                        }
                      }
                    })
                  }
                })
              } else if (res.cancel) {
                //console.log('用户点击取消')
              }
            }
          })
        } else if (res.cancel) {
          //console.log('用户点击取消')
        }
      }
    })
  },
  cxk: function () {
    //console.log("累啊")
    this.setData({
      hiddenmodalput2: !this.data.hiddenmodalput2
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    if (app.globalData.openid != null) {
      this.getUsrPoem()
    }

  },
})