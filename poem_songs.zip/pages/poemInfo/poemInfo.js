﻿const app = getApp()
const innerAudioContext = wx.createInnerAudioContext();
const recorderManager = wx.getRecorderManager()
// pages/poemInfo/poemInfo.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    poeminfo: [{}],
    name: '',
    author: '',
    poem: '',
    url: '',
    openid: "None",
    tempFilePath: ""
  },
  //开始录音的时候
  start: function () {
    innerAudioContext.stop()
    const options = {
      duration: 120000, //指定录音的时长，单位 ms
      sampleRate: 12000, //采样率
      numberOfChannels: 1, //录音通道数
      encodeBitRate: 64000, //编码码率
      format: 'mp3', //音频格式，有效值 aac/mp3
      frameSize: 50, //指定帧大小，单位 KB
    }
    //开始录音
    recorderManager.start(options);
    recorderManager.onStart(() => {
      //console.log('开始录音')
      wx.showToast({
        title: '开始录音',
        duration: 1000
      })
    });
    //错误回调
    recorderManager.onError((res) => {
      //console.log(res);
    })
  },
  //停止录音
  stop: function () {
    var that = this
    recorderManager.stop();
    wx.showToast({
      title: '停止录音',
      duration: 1000
    })
    recorderManager.onStop((res) => {
      //console.log(res)
      var tempFilePath = res.tempFilePath; // 文件临时路径
      //console.log('劳资获取到文件了，准备上传', tempFilePath)
      that.setData({
        tempFilePath: tempFilePath
      })
      recorderManager.onError((res) => {
        //console.log('小伙砸你录音失败了！')
      });
    })
  },
  play: function () {
    innerAudioContext.autoplay = true
    innerAudioContext.src = this.data.tempFilePath
    innerAudioContext.onPlay(() => {
      //console.log('开始播放')
    })
    innerAudioContext.onError((res) => {
      //console.log(res.errMsg)
      //console.log(res.errCode)
    })
  },
  send: function () {
    var that = this
    setTimeout(function () {
      var urls = app.globalData.url + "audiofile";
      var openid = app.globalData.openid
      //console.log(that.data.tempFilePath);
      //console.log(openid)
      wx.uploadFile({
        url: urls,
        filePath: that.data.tempFilePath,
        name: 'file',
        header: {
          'content-type': 'multipart/form-data'
        },
        formData: {
          openid: openid,
          poemname: that.data.poeminfo.poemName,
          author: that.data.poeminfo.author,
          poem: that.data.poeminfo.poem
        },
        success: function (res) {
          //console.log(res.data);
          wx.showModal({
            title: '提示',
            content: '语音保存成功，是否前往展示页面？',
            success(res) {
              if (res.confirm) {
                //console.log('用户点击确定')
                wx.switchTab({
                  url: "/pages/poemShow/poemShow"
                });
              } else if (res.cancel) {
                //console.log('用户点击取消')
              }
            }
          })
        },
        fail: function (res) {
          //console.log(res);
          wx.showModal({
            title: '提示',
            content: "请求失败，请确保网络是否正常或者上次录音文件已失效，请重新录制",
            showCancel: false,
            success: function (res) {}
          });
        }
      })
    }, 1000)
  },
  /**
   * 生命周期函数--监听页面加载
   */
  // 播放
  audioPlay: function () {
    innerAudioContext.src = app.globalData.url + "audio/" + this.data.poeminfo.poemName + "_" + this.data.poeminfo.author + ".mp3"
    innerAudioContext.play();
  },
  useraudio: function () {
    this.start()
  },
  onLoad: function () {
    wx.getSetting({
      success(res) {
        if (!res.authSetting['scope.record']) {
          wx.authorize({
            scope: 'scope.record',
            success() {
              // wx.startRecord()
              //console.log('权限开启')
            }
          })
        }
      }
    })
    var that = this
    var strs = ''
    var poeminfo = wx.getStorageSync('poeminfo', poeminfo)
    // //console.log(poeminfo)
    var reg = /[。!?]/g;
    strs = poeminfo.poem.split(reg);
    //console.log(strs)
    that.setData({
      poeminfo: poeminfo,
      name: poeminfo.poemName,
      author: poeminfo.author,
      url: app.globalData.url,
      poem: strs
    });
    wx.request({
      url: app.globalData.url + 'find_audio',
      method: 'POST',
      data: {
        poemName: this.data.poeminfo.poemName,
        author: this.data.poeminfo.author,
        poem: this.data.poeminfo.poem
      },
      success: function (res) {
        // 打印值
        //console.log(res.data)
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    // 退出页面停止播放
    innerAudioContext.stop();
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    // 退出页面停止播放
    innerAudioContext.stop();
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {}
})