﻿// pages/poemList/poemLsit.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    usepoemArr: []
  },
  del(e){
    var that=this
    var key = e.currentTarget.dataset.key
    //console.log(that.data.usepoemArr[key])
    wx.showModal({
      title: '提示',
      content: '是否确认删除该内容？',
      success(res) {
        if (res.confirm) {
          wx.request({
            url: app.globalData.url + "del_audio_poem",
            method: 'post',
            header: {
              'content-type': 'application/json'
            },
            data: {
              poem: that.data.usepoemArr[key]['poem'],
              flag: 2,
            },
            success: res => {
              wx.showToast({
                title: res.data.msg,
                duration: 1000
              })
              var item=that.data.usepoemArr
              item.splice(key,1)
              that.setData({
                usepoemArr:item
              })
            }
          })
        } else if (res.cancel) {
          //console.log('用户点击取消')
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    var that=this
    var use_poem=wx.getStorageSync('use_poem',use_poem)
    //console.log(use_poem)
    that.setData({
      usepoemArr:use_poem
    })
  },
// 预览图片
clickImg: function(e){
  var key = e.currentTarget.dataset.key
  wx.previewImage({
    current:this.data.usepoemArr[key]['imgurls'], // 当前显示图片的http链接
    urls: [this.data.usepoemArr[key]['imgurls']] // 需要预览的图片http链接列表
    })
},
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  }
})