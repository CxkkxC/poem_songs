﻿const app = getApp()
// pages/poemSong/poemSong.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    value: '',
    info: [{
      "poemName": "提示",
      "author": "",
      "poem": "可以输入作者，诗名或者诗句进行查找。"
    }],
    page: 1,
    pagesize: 50,
    isLoading: true,
    floorstatus: false,
    bg: '0'
  },
  onChange(e) {
    this.setData({
      value: e.detail
    });
  },
  // 不用点击确认进行搜，默认关闭先
  onSearch() {
    this.onClick()
    this.setData({
      bg: '1'
    })
  },

  // 跳转到诗详情页
  getPoeminfo: function (e) {
    var str = parseInt(e.currentTarget.id)
    //console.log(str)
    if (str.length == 0) {
      wx.showToast({
        title: '输入为空',
        duration: 1000
      })
    } else {
      var poeminfo = this.data.info[str]
      //console.log(poeminfo)
      if (poeminfo.poemName == "提示" || poeminfo.poemName == "请求成功" || poeminfo.poemName == "无") {
        wx.showToast({
          title: '此处不是诗哦',
          icon: 'fail',
          duration: 1000
        })
      } else {
        var that = this;
        // 查看是否授权
        wx.getSetting({
          success: function (res) {
            if (res.authSetting['scope.userInfo']) {
              wx.getUserInfo({
                success: function (res_user) {
                  if (app.globalData.openid != null) {
                    //console.log("已经获取到oppenid：", app.globalData.openid)
                    wx.setStorageSync("poeminfo", poeminfo)
                    wx.navigateTo({
                      url: "/pages/poemInfo/poemInfo",
                    })
                  } else {
                    wx.login({
                      success: res => {
                        // 获取到用户的 code 之后：res.code
                        //console.log("用户的code:" + res.code);
                        // 可以传给后台，再经过解析获取用户的 openid
                        // 或者可以直接使用微信的提供的接口直接获取 openid ，方法如下：
                        wx.request({
                          // 自行补上自己的 APPID 和 SECRET
                          url: app.globalData.url + "get_id",
                          method: 'post',
                          header: {
                            'content-type': 'application/json'
                          },
                          data: {
                            code: res.code,
                            headurl: res_user.userInfo.avatarUrl, //这些是用户的基本信息
                            nickname: res_user.userInfo.nickName, //获取昵称
                            gender: res_user.userInfo.gender //性别 0：未知、1：男、2：女
                          },
                          success: res => {
                            // 获取到用户的 openid
                            //console.log("用户的openid:" + res.data.openid);
                            app.globalData.openid = res.data.openid;
                            wx.setStorageSync("poeminfo", poeminfo)
                            wx.navigateTo({
                              url: "/pages/poemInfo/poemInfo",
                            })
                          }
                        });
                      }
                    });
                  }
                }
              });
            } else {
              wx.showModal({
                title: '提示',
                content: '您还未进行授权登录！是否前往授权？',
                success(res) {
                  if (res.confirm) {
                    //console.log('用户点击确定')
                    wx.switchTab({
                      url: "/pages/poemPeople/poemPeople"
                    });
                  } else if (res.cancel) {
                    //console.log('用户点击取消')
                    wx.showToast({
                      title: '取消授权',
                      duration: 1000
                    })
                  }
                }
              })
            }
          }
        });
      }
    }
  },
  // 点击查找返回结果
  onClick: function () {
    this.setData({
      bg: '1'
    })
    var str = this.data.value;
    if (str.length == 0) {
      wx.showToast({
        title: '输入为空',
        duration: 1000
      })
    } else {
      var that = this;
      wx.showLoading({
        title: '加载中',
        icon: 'loading'
      });
      wx.request({
        url: app.globalData.url + 'getPoem',
        method: 'POST',
        data: {
          poemInfo: str,
          query: '测试',
          page: that.data.page,
          pagesize: 50
        },
        // header:{'content-type': 'application/x-www-form-urlencoded;charset=utf-8'},
        success: function (res) {
          // 打印值
          var temp = [{
            "poemName": "请求成功",
            "author": ""
          }]
          temp[0]['author'] = "总共：" + res.data.msg + "首"
          //console.log(res.data)
          const entities = [...temp, ...res.data.info]
          // 传递数据
          that.setData({
            isLoading: false,
            info: entities
          })
        },
        complete: () => {
          wx.hideLoading()
        }
      })
    }
  },

  // 获取滚动条当前位置 回顶部
  onPageScroll: function (e) {
    // //console.log(e)
    if (e.scrollTop > 100) {
      this.setData({
        floorstatus: true
      });
    } else {
      this.setData({
        floorstatus: false
      });
    }
  },
  //回到顶部
  goTop: function (e) { // 一键回到顶部
    if (wx.pageScrollTo) {
      wx.pageScrollTo({
        scrollTop: 0
      })
    } else {
      wx.showModal({
        title: '提示',
        content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。'
      })
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var str = this.data.value;
    let {
      isLoading,
      page
    } = this.data
    if (isLoading) {
      return
    }
    this.setData({
      isLoading: true
    })
    page = page + 1
    wx.showLoading({
      title: '加载中',
      icon: 'loading'
    });
    wx.request({
      url: app.globalData.url + 'getPoem',
      method: 'POST',
      data: {
        poemInfo: str,
        query: '测试',
        page: page,
        pagesize: 50
      },
      success: (res) => {
        //console.log(res.data)
        const entities = [...this.data.info, ...res.data.info]
        this.setData({
          info: entities,
          page: page,
          isLoading: false,
        })

      },
      complete: () => {
        wx.hideLoading()
      }
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {}
})