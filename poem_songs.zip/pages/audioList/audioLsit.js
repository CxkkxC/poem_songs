﻿// pages/audioList/audioLsit.js
const app = getApp();
//创建audio控件
const myaudio = wx.createInnerAudioContext();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    audioArr: [],
    audKey: '',
  },
  del(e) {
    var that=this
    var key = e.currentTarget.dataset.key
    //console.log(that.data.audioArr[key]['src'])
    wx.showModal({
      title: '提示',
      content: '是否确认删除该内容？',
      success(res) {
        if (res.confirm) {
          //console.log('用户点击确定')
          wx.request({
            url: app.globalData.url + "del_audio_poem",
            method: 'post',
            header: {
              'content-type': 'application/json'
            },
            data: {
              audioname: that.data.audioArr[key]['src'],
              flag: 1,
            },
            success: res => {
              wx.showToast({
                title: res.data.msg,
                duration: 1000
              })
              var item=that.data.audioArr
              item.splice(key,1)
              that.setData({
                audioArr:item
              })
            }
          })
        } else if (res.cancel) {
          //console.log('用户点击取消')
        }
      }
    })
  },
  //音频播放  
  audioPlay(e) {
    var that = this,
      // id = e.currentTarget.dataset.id,
      key = e.currentTarget.dataset.key,
      audioArr = that.data.audioArr;
    //设置状态
    audioArr.forEach((v, i, array) => {
      v.bl = '0';
      if (i == key) {
        v.bl = '1';
      }
    })
    that.setData({
      audioArr: audioArr,
      audKey: key,
    })
    myaudio.autoplay = true;
    var audKey = that.data.audKey,
      vidSrc = audioArr[audKey].src;
    myaudio.src = vidSrc;
    myaudio.play();
    //开始监听
    myaudio.onPlay(() => {
      //console.log('开始播放');
    })
    //结束监听
    myaudio.onEnded(() => {
      //console.log('自动播放完毕');
      audioArr[key].bl = '0';
      that.setData({
        audioArr: audioArr,
      })
    })
    //错误回调
    myaudio.onError((err) => {
      //console.log(err);
      audioArr[key].bl = '0';
      that.setData({
        audioArr: audioArr,
      })
      return
    })
  },
  // 音频停止
  stop(e) {
    var that = this,
      key = e.currentTarget.dataset.key,
      audioArr = that.data.audioArr;
    //设置状态
    audioArr.forEach((v, i, array) => {
      v.bl = '0';
    })
    that.setData({
      audioArr: audioArr
    })
    myaudio.stop();
    //停止监听
    myaudio.onStop(() => {
      //console.log('停止播放');
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    var that = this
    var use_audio = wx.getStorageSync('use_audio', use_audio)
    //console.log(use_audio)
    that.setData({
      audioArr: use_audio
    })
    //console.log(that.data.audioArr)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var use_audio = wx.getStorage({
      key: 'use_audio',
    })
    this.setData({
      audioArrr: use_audio
    })
  },

/**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    clearTimeout()
    myaudio.stop();
    var that = this
    //停止监听
    myaudio.onStop(() => {
      var audioArr = that.data.audioArr;
      audioArr.forEach((v, i, array) => {
        v.bl = '0';
      })
      that.setData({
        audioArr: audioArr
      })
      //console.log('停止播放');
    })
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    clearTimeout()
    myaudio.stop();
    var that = this
    //停止监听
    myaudio.onStop(() => {
      var audioArr = that.data.audioArr;
      audioArr.forEach((v, i, array) => {
        v.bl = '0';
      })
      that.setData({
        audioArr: audioArr
      })
      //console.log('停止播放');
    })
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})