﻿// pages/poemShow/poemShow.js
const app = getApp();
//创建audio控件
const myaudio = wx.createInnerAudioContext();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    audioArr: [{}],
    usepoemArr:[{}],
    page: 1,
    pagesize: 50,
    audKey: '', //当前选中的音频key
    isLoading: true,
    floorstatus: false,
    floor: true,
    active:0,
    hiddenmodalput: true,
    tab: ['用户语音展示', '用户原创展示'],
    filelist: [],
    title: "",
    author: '',
    poem: "",
    imgtempath: null,
    value:''
  },

  // 切换栏目
  onChanges(event) {
    this.setData({
      page:1
    })
    //console.log(this.data.page)
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
  },
// 预览图片
clickImg: function(e){
  var key = e.currentTarget.dataset.key
  wx.previewImage({
    current:this.data.usepoemArr[key]['imgurls'], // 当前显示图片的http链接
    urls: [this.data.usepoemArr[key]['imgurls']] // 需要预览的图片http链接列表
    })
},

  // 搜索框
  onChange(e) {
    this.setData({
      value: e.detail
    });
  },
  // 搜索框 回车键搜索
  onSearch() {
    this.onClick()
  },
  // 搜索栏 点击查找搜索
  onClick: function () {
    var that = this;
    var str = that.data.value;
    //console.log(str)
    wx.showLoading({
      title: '加载中',
      icon: 'loading'
    });
    wx.request({
      url: app.globalData.url + 'getAudioList',
      method: 'POST',
      data: {
        page: 1,
        pagesize: 50,
        value:str
      },
      success: function (res) {
        //console.log(res.data)
        // 传递数据
        that.setData({
          isLoading: false,
          audioArr: res.data.info,
          usepoemArr:res.data.usepoem
        })
      },
      complete: () => {
        wx.hideLoading()
      }
    })
  },

  //音频播放  
  audioPlay(e) {
    var that = this,
      // id = e.currentTarget.dataset.id,
      key = e.currentTarget.dataset.key,
      audioArr = that.data.audioArr;

    //设置状态
    audioArr.forEach((v, i, array) => {
      v.bl = '0';
      if (i == key) {
        v.bl = '1';
      }
    })
    that.setData({
      audioArr: audioArr,
      audKey: key,
    })

    myaudio.autoplay = true;
    var audKey = that.data.audKey,
      vidSrc = audioArr[audKey].src;
    myaudio.src = vidSrc;
    myaudio.play();

    //开始监听
    myaudio.onPlay(() => {
      //console.log('开始播放');
    })
    //结束监听
    myaudio.onEnded(() => {
      //console.log('自动播放完毕');
      audioArr[key].bl = '0';
      that.setData({
        audioArr: audioArr,
      })
    })
    //错误回调
    myaudio.onError((err) => {
      //console.log(err);
      audioArr[key].bl = '0';
      that.setData({
        audioArr: audioArr,
      })
      return
    })
  },

  // 音频停止
  stop(e) {
    var that = this,
      key = e.currentTarget.dataset.key,
      audioArr = that.data.audioArr;
    //设置状态
    audioArr.forEach((v, i, array) => {
      v.bl = '0';
    })
    that.setData({
      audioArr: audioArr
    })

    myaudio.stop();

    //停止监听
    myaudio.onStop(() => {
      //console.log('停止播放');
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {},
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    wx.showLoading({
      title: '加载中',
      icon: 'loading'
    });
    wx.request({
      url: app.globalData.url + 'getAudioList',
      method: 'POST',
      data: {
        page: 1,
        pagesize: 50,
        value:that.data.value
      },
      success: function (res) {
        //console.log(res.data)
        // 传递数据
        that.setData({
          isLoading: false,
          audioArr: res.data.info,
          usepoemArr:res.data.usepoem
        })
      },
      complete: () => {
        wx.hideLoading()
      }
    })
    that.setData({
      author:app.globalData.nickname
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    clearTimeout()
    myaudio.stop();
    var that = this
    //停止监听
    myaudio.onStop(() => {
      var audioArr = that.data.audioArr;
      audioArr.forEach((v, i, array) => {
        v.bl = '0';
      })
      that.setData({
        audioArr: audioArr
      })
      //console.log('停止播放');
    })
    that.setData({
      value:''
    })
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    clearTimeout()
    myaudio.stop();
    var that = this
    //停止监听
    myaudio.onStop(() => {
      var audioArr = that.data.audioArr;
      audioArr.forEach((v, i, array) => {
        v.bl = '0';
      })
      that.setData({
        audioArr: audioArr
      })
      //console.log('停止播放');
    })
    that.setData({
      value:''
    })
  },
  add: function () {
    if (app.globalData.openid == null) {
      wx.showModal({
        title: '提示',
        content: '您还未进行登录，是否前往登录？',
        success(res) {
          if (res.confirm) {
            //console.log('用户点击确定')
            wx.switchTab({
              url: "/pages/poemPeople/poemPeople"
            });
          } else if (res.cancel) {
            //console.log('用户点击取消')
            wx.showToast({
              title: '未登录',
              icon: "none",
              duration: 1000
            })
          }
        }
      })
    } else {
      this.setData({
        hiddenmodalput: !this.data.hiddenmodalput
      })
    }
    // wx.navigateTo({
    //   url: "/pages/poemAdd/poemAdd"
    // });
  },
  gettitle: function (e) {
    //console.log(e.detail.value)
    this.setData({
      title: e.detail.value
    })
  },
  getauthor: function (e) {
    //console.log(e.detail.value)
    this.setData({
      author: e.detail.value
    })
  },
  getpoem: function (e) {
    //console.log(e.detail)
    this.setData({
      poem: e.detail.value
    })
  },
  //取消按钮
  cancel: function () {
    this.setData({
      hiddenmodalput: true,
      author:app.globalData.nickname
    });
  },
  //确认
  confirm: function () {
    var that = this
    if (this.data.title.length != 0 && this.data.author.length != 0 && this.data.poem.length != 0) {
      //console.log(this.data.title)
      //console.log(this.data.author)
      //console.log(this.data.poem)
      if (this.data.imgtempath != null) {
        if (this.data.imgtempath.file.size / 1024 > 500) {
          wx.showModal({
            title: '提示',
            content: '图片太大了,不能超过500k，当前大小' + this.data.imgtempath.file.size / 1024 + 'k',
            success(res) {
              if (res.confirm) {
                //console.log('用户点击确定')
              } else if (res.cancel) {
                //console.log('用户点击取消')

              }
            }
          })
        } else {
          wx.uploadFile({
            url: app.globalData.url + "up_photo", // 仅为示例，非真实的接口地址
            filePath: this.data.imgtempath.file.path,
            name: 'file',
            formData: {
              openid: app.globalData.openid,
              title: this.data.title,
              author: this.data.author,
              poem: this.data.poem,
            },
            success(res) {
              if (typeof (res.data) == 'string') {
                res.data = JSON.parse(res.data.trim());
              }
              //console.log(res.data)
              //console.log(res.data.msg)
              that.setData({
                filelist: [],
                hiddenmodalput: true,
                title: "",
                author: "",
                poem: ""
              });
              wx.showToast({
                title:res.data.msg,
                icon:"none",
                duration: 1000
              })
              that.setData({
                value:''
              })
              that.onShow()
              // //console.log(this.data.fileList)
            }
          })
        }
      } else {
        //console.log(this.data.imgtempath)
        wx.request({
          url: app.globalData.url + "up_photo2", // 仅为示例，非真实的接口地址
          method: 'POST',
          data: {
            openid: app.globalData.openid,
            title: this.data.title,
            author: this.data.author,
            poem: this.data.poem,
          },
          success(res) {
            if (typeof (res.data) == 'string') {
              res.data = JSON.parse(res.data.trim());
            }
            //console.log(res.data)
            //console.log(res.data.msg)
            that.setData({
              hiddenmodalput: true,
              title: "",
              author: app.globalData.nickname,
              poem: ""
            });
            wx.showToast({
              title:res.data.msg,
              icon:"none",
              duration: 1500
            })
            that.setData({
              value:''
            })
            that.onShow()
            // //console.log(this.data.fileList)
          }
        })
      }
    } else {
      wx.showToast({
        title: '输入为空',
        duration: 1000
      })
    }
  },
  afterRead(event) {
    var that = this
    //console.log(event.detail.file.path)
    var fileLists = [];
    fileLists = that.data.filelist
    let imagesInfo = {
      url: event.detail.file.path
    }
    fileLists.push(imagesInfo)
    that.setData({
      imgtempath: event.detail,
      filelist: fileLists
    })
  },
  delete(event) {
    //console.log(event.detail)
    var list = this.data.filelist;
    list.splice(event.detailt, 1)
    this.setData({
      filelist: list
    })
  },

  // 获取滚动条当前位置 回顶部
  onPageScroll: function (e) {
    // //console.log(e)
    if (e.scrollTop > 100) {
      this.setData({
        floorstatus: true,
        floor: false
      });
    } else {
      this.setData({
        floorstatus: false,
        floor: true
      });
    }
  },
  //回到顶部
  goTop: function (e) { // 一键回到顶部
    if (wx.pageScrollTo) {
      wx.pageScrollTo({
        scrollTop: 0
      })
    } else {
      wx.showModal({
        title: '提示',
        content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。'
      })
    }
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    var that=this
    that.onshow()
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var that = this
    let {
      isLoading,
      page
    } = this.data
    if (isLoading) {
      return
    }
    this.setData({
      isLoading: true
    })
    page = page + 1
    wx.showLoading({
      title: '加载中',
      icon: 'loading'
    });
    wx.request({
      url: app.globalData.url + 'getAudioList',
      method: 'POST',
      data: {
        page: page,
        pagesize: 50,
        value:that.data.value
      },
      success: function (res) {
        //console.log(res.data)
        // 传递数据
        const entities = [...that.data.audioArr, ...res.data.info]
        that.setData({
          page: page,
          isLoading: false,
          audioArr: entities
        })
      },
      complete: () => {
        wx.hideLoading()
      }
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {}
})